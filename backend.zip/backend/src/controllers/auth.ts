import { Request, Response } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import pool from '../db';

export async function signup(req: Request, res: Response) {
  try {
    const { firstname, lastname, username, email, password, dob, gender } = req.body;
    const profilePhoto = req.file?.filename;

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Insert user into database
    const [result] = await pool.execute(
      'INSERT INTO users (firstname, lastname, username, email, password, dob, gender, profile_photo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [firstname, lastname, username, email, hashedPassword, dob, gender, profilePhoto]
    );

    // Generate JWT token
    const token = jwt.sign(
      { userId: (result as any).insertId },
      process.env.JWT_SECRET || 'fallback-secret',
      { expiresIn: '24h' }
    );

    res.status(201).json({ token });
  } catch (error: any) {
    if (error.code === 'ER_DUP_ENTRY') {
      res.status(400).json({ error: 'Email or username already exists' });
    } else {
      console.error('Signup error:', error);
      res.status(500).json({ error: 'Error creating user' });
    }
  }
}

export async function login(req: Request, res: Response) {
  try {
    const { email, password } = req.body;

    // Get user from database
    const [rows] = await pool.execute(
      'SELECT * FROM users WHERE email = ?',
      [email]
    );

    const user = (rows as any)[0];
    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    // Check password
    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    // Generate JWT token
    const token = jwt.sign(
      { userId: user.id },
      process.env.JWT_SECRET || 'fallback-secret',
      { expiresIn: '24h' }
    );

    res.json({ token });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Error during login' });
  }
}